import Cocoa
import ApplicationServices

/// Чтение и запись выделенного текста НАПРЯМУЮ через Accessibility API,
/// без участия буфера обмена (⌘C/⌘V).
///
/// Почему это лучше буфера:
///   - не трогает пользовательский буфер обмена вообще (нечего терять и восстанавливать)
///   - нет гонок между чтением, записью и отложенным восстановлением
///   - мгновенно: нет ожиданий доставки синтетических событий и changeCount
///   - не зависит от того успело ли приложение обработать вставку
///
/// Ограничение: поддерживают не все приложения.
///   Работает: нативные Cocoa (TextEdit, Notes, Mail, поля Safari, Xcode, Terminal…)
///   Не работает / частично: Electron (Telegram, VS Code, Slack), часть Java/Qt.
/// Поэтому вызывающий код при неудаче откатывается на клипбордный путь.
enum AXSelection {

    /// Результат попытки прочитать выделение через AX.
    enum ReadResult {
        /// Успешно прочитали выделенный текст (может быть пустым — значит выделения нет).
        case ok(String)
        /// AX недоступен для этого элемента/приложения — нужен fallback на ⌘C.
        case unsupported
    }

    /// Таймаут AX-запросов. Без него обращение к подвисшему приложению
    /// блокирует поток на десятки секунд.
    private static let messagingTimeout: Float = 0.5

    /// Получить сфокусированный UI-элемент фронтмост-приложения.
    ///
    /// ВАЖНО: вызывать НЕ с главного потока — AX-запрос к неотвечающему
    /// приложению блокирует поток до таймаута, а замороженный main RunLoop
    /// ломает доставку событий (мы уже наступали на это с ⌘C).
    private static func focusedElement() -> AXUIElement? {
        let systemWide = AXUIElementCreateSystemWide()
        AXUIElementSetMessagingTimeout(systemWide, messagingTimeout)

        var focused: CFTypeRef?
        let err = AXUIElementCopyAttributeValue(
            systemWide,
            kAXFocusedUIElementAttribute as CFString,
            &focused
        )
        guard err == .success, let f = focused else { return nil }
        let element = f as! AXUIElement
        AXUIElementSetMessagingTimeout(element, messagingTimeout)
        return element
    }

    /// Идентификатор процесса, которому принадлежит поле с фокусом ввода.
    ///
    /// Отличается от NSWorkspace.frontmostApplication: системные накладки
    /// (поиск программ, Spotlight) не становятся «активным приложением», и
    /// frontmost продолжает показывать то, что было под ними. А фокус ввода
    /// у них свой, и через AX он виден честно.
    ///
    /// Результат кэшируется на короткое время: запрос идёт на каждой границе
    /// слова, а обращение к чужому процессу не бесплатно.
    private static var cachedFocusApp: (id: String?, at: Date)?

    static func focusedAppBundleID() -> String? {
        if let c = cachedFocusApp, Date().timeIntervalSince(c.at) < 0.5 {
            return c.id
        }
        let systemWide = AXUIElementCreateSystemWide()
        AXUIElementSetMessagingTimeout(systemWide, 0.1)

        var focused: CFTypeRef?
        guard AXUIElementCopyAttributeValue(systemWide,
                kAXFocusedUIElementAttribute as CFString, &focused) == .success,
              let f = focused else {
            cachedFocusApp = (nil, Date())
            return nil
        }
        let element = f as! AXUIElement
        var pid: pid_t = 0
        guard AXUIElementGetPid(element, &pid) == .success else {
            cachedFocusApp = (nil, Date())
            return nil
        }
        let id = NSRunningApplication(processIdentifier: pid)?.bundleIdentifier
        cachedFocusApp = (id, Date())
        return id
    }

    /// Прочитать выделенный текст.
    static func read() -> ReadResult {
        guard let element = focusedElement() else { return .unsupported }

        var value: CFTypeRef?
        let err = AXUIElementCopyAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            &value
        )

        guard err == .success else {
            // Атрибут не поддерживается этим элементом
            return .unsupported
        }
        guard let str = value as? String else {
            return .unsupported
        }
        return .ok(str)
    }

    /// Заменить выделенный текст новым.
    /// Возвращает true если запись удалась.
    static func write(_ newText: String) -> Bool {
        guard let element = focusedElement() else { return false }

        // Проверяем что атрибут вообще доступен для записи —
        // иначе AXUIElementSetAttributeValue может тихо ничего не сделать.
        var settable: DarwinBoolean = false
        let checkErr = AXUIElementIsAttributeSettable(
            element,
            kAXSelectedTextAttribute as CFString,
            &settable
        )
        guard checkErr == .success, settable.boolValue else { return false }

        let err = AXUIElementSetAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            newText as CFTypeRef
        )
        return err == .success
    }

    /// Полный цикл: прочитать выделение, преобразовать, записать обратно.
    /// Возвращает исходный выделенный текст если всё удалось, иначе nil
    /// (значит нужен fallback на клипбордный путь).
    ///
    /// transform вызывается только если есть непустое выделение.
    static func swapSelection(_ transform: (String) -> String) -> String? {
        guard let element = focusedElement() else { return nil }

        var value: CFTypeRef?
        let readErr = AXUIElementCopyAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            &value
        )
        guard readErr == .success, let original = value as? String else { return nil }
        guard !original.isEmpty else { return nil }

        var settable: DarwinBoolean = false
        let checkErr = AXUIElementIsAttributeSettable(
            element,
            kAXSelectedTextAttribute as CFString,
            &settable
        )
        guard checkErr == .success, settable.boolValue else { return nil }

        let replaced = transform(original)
        guard replaced != original else { return original }

        let writeErr = AXUIElementSetAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            replaced as CFTypeRef
        )
        guard writeErr == .success else { return nil }

        return original
    }
}
