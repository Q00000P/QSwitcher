import Foundation

/// Информация о версии. BUILD_NUMBER подставляется при сборке скриптом make-app.sh.
enum AppVersion {
    static let version = "3.0"
    static let build = BuildInfo.number
    static let buildDate = BuildInfo.date

    static var fullString: String {
        return "QSwitcher \(version) (билд \(build))"
    }
}

/// Этот блок переписывается make-app.sh при каждой сборке.
/// Не редактировать руками — значения подставляются автоматически.
enum BuildInfo {
    static let number = "0"
    static let date = "не собрано"
}
